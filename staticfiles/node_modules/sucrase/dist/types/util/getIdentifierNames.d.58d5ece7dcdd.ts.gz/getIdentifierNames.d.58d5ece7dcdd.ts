import type { Token } from "../parser/tokenizer";
/**
 * Get all identifier names in the code, in order, including duplicates.
 */
export default function getIdentifierNames(code: string, tokens: Array<Token>): Array<string>;
