import type { Options } from "../index";
export interface JSXPragmaInfo {
    base: string;
    suffix: string;
    fragmentBase: string;
    fragmentSuffix: string;
}
export default function getJSXPragmaInfo(options: Options): JSXPragmaInfo;
