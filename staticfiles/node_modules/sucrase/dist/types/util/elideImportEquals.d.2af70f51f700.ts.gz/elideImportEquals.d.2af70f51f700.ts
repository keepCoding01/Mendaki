import type TokenProcessor from "../TokenProcessor";
export default function elideImportEquals(tokens: TokenProcessor): void;
