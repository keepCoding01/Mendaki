export declare function jsxParseElement(): void;
export declare function nextJSXTagToken(): void;
