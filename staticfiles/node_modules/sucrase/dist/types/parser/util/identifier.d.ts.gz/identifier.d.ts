export declare const IS_IDENTIFIER_CHAR: Uint8Array;
export declare const IS_IDENTIFIER_START: Uint8Array;
