export declare const WHITESPACE_CHARS: Array<number>;
export declare const skipWhiteSpace: RegExp;
export declare const IS_WHITESPACE: Uint8Array;
