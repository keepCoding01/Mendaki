"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _loadconfig = require("../lib/load-config");
const _default = _loadconfig.loadConfig;
