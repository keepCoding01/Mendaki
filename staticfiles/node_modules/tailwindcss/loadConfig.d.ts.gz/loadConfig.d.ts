import type { Config } from './types/config'

declare function loadConfig(path: string): Config
export = loadConfig
