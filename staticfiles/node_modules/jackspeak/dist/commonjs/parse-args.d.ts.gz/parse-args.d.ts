/// <reference types="node" />
import * as util from 'util';
export declare const parseArgs: typeof util.parseArgs;
//# sourceMappingURL=parse-args-cjs.d.cts.map