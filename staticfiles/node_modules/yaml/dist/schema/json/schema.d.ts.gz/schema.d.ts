import type { CollectionTag, ScalarTag } from '../types';
export declare const schema: (CollectionTag | ScalarTag)[];
